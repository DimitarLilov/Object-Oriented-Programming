﻿namespace Bank.Interfaces
{
    using Interfaces;
    public interface ICustomer
    {
        string Name { get; set; }
    }
}
