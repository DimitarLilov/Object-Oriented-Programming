﻿namespace TheSlum
{
    using GameEngine;

    public class Program
    {
        static void Main()
        {
            Engine engine = new ExtendedEngine();
            engine.Run();
        }
    }
}
