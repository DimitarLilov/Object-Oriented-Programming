﻿namespace _01.Galactic_GPS
{
    public enum Planet
    {
        Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune
    }
}
