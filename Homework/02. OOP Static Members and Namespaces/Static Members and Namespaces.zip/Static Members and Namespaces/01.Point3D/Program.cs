﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01.Point3D
{
    public class Program
    {
        static void Main(string[] args)
        {
            var point = new Point3D(1.6, 6.9, 8);
            Console.WriteLine(point);
        }
    }
}
