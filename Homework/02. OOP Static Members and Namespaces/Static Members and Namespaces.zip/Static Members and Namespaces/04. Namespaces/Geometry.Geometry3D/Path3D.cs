﻿namespace Geometry.Geometry3D
{
    class Path3D
    {
    }
}
