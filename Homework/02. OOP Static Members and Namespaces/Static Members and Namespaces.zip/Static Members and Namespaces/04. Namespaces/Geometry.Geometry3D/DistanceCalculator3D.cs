﻿namespace Geometry.Geometry3D
{
    class DistanceCalculator3D
    {
    }
}
