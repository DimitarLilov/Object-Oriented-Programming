﻿namespace Geometry.Geometry3D
{
    class Point3D
    {
    }
}
