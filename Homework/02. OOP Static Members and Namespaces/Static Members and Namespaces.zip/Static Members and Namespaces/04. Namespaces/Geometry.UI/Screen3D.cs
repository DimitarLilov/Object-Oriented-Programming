﻿namespace Geometry.UI
{
    class Screen3D
    {
    }
}
