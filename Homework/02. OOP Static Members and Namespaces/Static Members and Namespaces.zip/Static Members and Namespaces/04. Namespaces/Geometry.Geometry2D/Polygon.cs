﻿namespace Geometry.Geometry2D
{
    class Polygon
    {
    }
}
