﻿namespace Geometry.Geometry2D
{
    class Ellipse
    {
    }
}
