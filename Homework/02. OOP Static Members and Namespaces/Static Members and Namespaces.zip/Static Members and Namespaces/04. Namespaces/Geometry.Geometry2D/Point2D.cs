﻿namespace Geometry.Geometry2D
{
    class Point2D
    {
    }
}
