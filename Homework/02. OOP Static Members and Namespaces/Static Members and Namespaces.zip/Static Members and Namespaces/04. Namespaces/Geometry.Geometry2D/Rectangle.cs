﻿namespace Geometry.Geometry2D
{
    class Rectangle
    {
    }
}
