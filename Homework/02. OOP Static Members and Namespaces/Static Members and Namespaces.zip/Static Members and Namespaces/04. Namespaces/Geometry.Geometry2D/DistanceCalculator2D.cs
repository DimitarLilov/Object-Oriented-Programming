﻿namespace Geometry.Geometry2D
{
    class DistanceCalculator2D
    {
    }
}
